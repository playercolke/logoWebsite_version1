export default class AppWork {
    constructor(initName) {
        this.name = initName;
    }

    setName(initName) {
        this.name = initName;
    }

    getName() {
        return this.name;
    }
}